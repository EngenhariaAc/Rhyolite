function showFact() {
  const facts = [
    "Riolit memiliki kandungan silika sangat tinggi.",
    "Sering ditemukan di daerah vulkanik.",
    "Strukturnya bisa menyerupai kaca seperti obsidian.",
    "Terbentuk dari lava yang sangat kental."
  ];

  const random = facts[Math.floor(Math.random() * facts.length)];
  document.getElementById("fact").innerText = random;
}
