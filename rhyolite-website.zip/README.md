# Rhyolite Website

Website sederhana bertema batuan riolit.

## Fitur
- Informasi dasar riolit
- Fakta interaktif
- Desain cerah

## Cara Menjalankan
Buka index.html di browser.
